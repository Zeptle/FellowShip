﻿Imports System.Net
Imports System.IO
Imports SearchXML.SearchXML

Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub BTN_Search_Click(sender As Object, e As System.EventArgs) Handles BTN_Search.Click
        'Must be at least 2 characters long

        Dim URL As String = "https://demo.fellowshiponeapi.com/v1/People/Search?searchFor=" & SearchTextBox.Text & "%&Mode=Demo"

        Dim responseFromServer As String

        responseFromServer = RetrieveData(URL)

        Dim xmlDS2 = XElement.Parse(responseFromServer)
        Dim query = (From c In xmlDS2.Descendants("person")
                   Select firstName = c.Element("firstName").Value, lastName = c.Element("lastName").Value, _
        PersonID = c.Attribute("id").Value + "&hid=" + c.Attribute("householdID").Value, HouseHoldID = c.Attribute("householdID").Value, count = c.Parent.Attribute("count").Value).ToList()


        gvResults.DataSource = query
        gvResults.DataBind()

    End Sub
End Class
