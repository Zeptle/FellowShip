﻿Imports System.Net
Imports System.IO
Imports SearchXML.SearchXML
Imports System.Xml
Imports System.Data

Partial Class UserEdit
   Inherits System.Web.UI.Page

   Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

      If Page.IsPostBack = False Then

         Dim PersonID = Request.QueryString("ID")
         Dim HouseHoldID = Request.QueryString("HID")
         If PersonID = "" Then
            PersonID = "3958658"
         End If

         If HouseHoldID = "" Then
            HouseHoldID = "3209361"
         End If


         Dim URL As String = "https://demo.fellowshiponeapi.com/v1/People/Search?id=" & PersonID & "&Mode=Demo"
         Dim HID As String = "https://demo.fellowshiponeapi.com/v1/Households/" & HouseHoldID & "?Mode=Demo"
         Dim HAddURL As String = "https://demo.fellowshiponeapi.com/v1/Households/" & HouseHoldID & "/Addresses?mode=Demo"
         Dim HCommURL As String = "https://demo.fellowshiponeapi.com/v1/Households/" & HouseHoldID & "/Communications?mode=Demo"
         Dim responseFromServer As String

         'Get User Personal Information
         responseFromServer = RetrieveData(URL)
         UserInformation(responseFromServer)

         'Get User Personal Information
         responseFromServer = RetrieveData(HID)
         HouseHoldInformation(responseFromServer)

         'Get User Address by HouseHoldID
         responseFromServer = RetrieveData(HAddURL)
         addressfind(responseFromServer)

         'Get User Communication
         responseFromServer = RetrieveData(HCommURL)
         communicationsfind(responseFromServer)
      Else
         If Request.Form("test") <> "" Then
            Response.Write(Request.Form("test"))
         End If

      End If

   End Sub
   Protected Sub UserInformation(ByRef responseFromServer As String)
      Dim xmlDS2 = XElement.Parse(responseFromServer)
      Dim Userquery = (From c In xmlDS2.Descendants("person")
                  Select firstName = c.Element("firstName").Value, lastName = c.Element("lastName").Value,
                  DOB = c.Element("dateOfBirth").Value).FirstOrDefault()

      Dim fullName As String = Userquery.firstName.ToString & " " & Userquery.lastName.ToString
      Dim DOBDate As DateTime = Convert.ToString(Userquery.DOB)
      HeaderLabel.Text = fullName & "<br />DOB:" & DOBDate.ToString("d")

   End Sub
   Protected Sub HouseHoldInformation(ByRef responseFromServer As String)
      Dim xmlDS2 = XElement.Parse(responseFromServer)
      Dim Userquery = (From c In xmlDS2.Descendants("household")
                  Select householdName = c.Element("householdName").Value, householdFirstName = c.Element("householdFirstName").Value,
                  lastUpdatedDate = c.Element("lastUpdatedDate").Value, householdSortName = c.Element("householdSortName").Value).FirstOrDefault()


      Using reader As XmlReader = XmlReader.Create(New StringReader(responseFromServer))

         reader.ReadToFollowing("householdName")
         reader.MoveToFirstAttribute()
         HouseHoldLabeltext.Text = reader.ReadElementContentAsString()

         reader.ReadToFollowing("householdSortName")
         reader.MoveToFirstAttribute()
         HouseHoldLabel.Text = reader.ReadElementContentAsString()
         HouseHoldLabel.Text = HouseHoldLabel.Text & " House Members"

         reader.ReadToFollowing("lastUpdatedDate")
         reader.MoveToFirstAttribute()
         Dim time As DateTime = reader.ReadElementContentAsString()
         ActivityLabel.Text = time.ToString("g")



      End Using

   End Sub
   Protected Sub addressfind(ByRef responseFromServer As String)
      Dim xmlDS2 = XElement.Parse(responseFromServer)
      Dim Userquery = (From c In xmlDS2.Descendants("address")
              Select AddressID = c.Attribute("id").Value, address1 = c.Element("address1").Value, address2 = c.Element("address2"),
              address3 = c.Element("address3").Value, City = c.Element("city").Value, createdDate = c.Element("createdDate").Value, postalcode = c.Element("postalCode").Value,
              country = c.Element("country").Value, stProvince = c.Element("stProvince").Value, addressDate = c.Element("addressDate").Value, lastUpdatedDate = c.Element("lastUpdatedDate").Value,
              addressComment = c.Element("addressComment").Value, Name = c.Descendants("name").Value).ToList()

      'GridView1.DataSource = Userquery
      'GridView1.DataBind()

      AAListView1.DataSource = Userquery
      AAListView1.DataBind()

      'Data Bind to list view

   End Sub
   Protected Sub communicationsfind(ByRef responseFromServer As String)
      Dim xmlDS2 = XElement.Parse(responseFromServer)
      Dim Userquery = (From c In xmlDS2.Descendants("communication")
                  Select commType = c.Element("communicationGeneralType").Value, CommValue = c.Element("communicationValue").Value, listed = c.Element("listed").Value,
                  Comment = c.Element("communicationComment").Value, createdDate = c.Element("createdDate").Value, lastUpdatedDate = c.Element("lastUpdatedDate").Value,
                  CommID = c.Attribute("id").Value, Name = c.Descendants("name").Value).ToList()

      'Data Bind to list view

      CommListView.DataSource = Userquery
      CommListView.DataBind()

   End Sub

   Protected Sub DeleteLinkButtonComm_Click(sender As Object, e As CommandEventArgs)
      'Removes the record from the webservice

      Dim var As String
      Dim url As String
      Dim Action As String()
      var = e.CommandArgument.ToString()

      Action = var.Split("-")

      Select Case Action(0)
         Case 999
            url = "https://demo.fellowshiponeapi.com/v1/Communications/" & Action(1) & "?mode=demo"
         Case 997
            url = "https://demo.fellowshiponeapi.com/v1/Addresses/" & Action(1) & "?mode=demo"
      End Select

      PostXMLData(url, 3, "")

      Redirect()

   End Sub

   Protected Sub EditLinkButtonComm_Click(sender As Object, e As CommandEventArgs)
      Dim var As String = e.CommandArgument.ToString()
      Dim Action As String()
      Dim url As String

      Action = var.Split("-")

      Select Case Action(0)
         Case 999
            url = "https://demo.fellowshiponeapi.com/v1/Communications/" & Action(1) & "?mode=demo"
            CommListView.Visible = False
            EditComunicationPanel.Visible = True
            EDITAddressPanel.Visible = False
            AAListView1.Visible = False
            ADDAddressPanel.Visible = False
         Case 997
            url = "https://demo.fellowshiponeapi.com/v1/Addresses/" & Action(1) & "?mode=demo"
            CommListView.Visible = False
            EditComunicationPanel.Visible = False
            EDITAddressPanel.Visible = True
            AAListView1.Visible = False
            ADDAddressPanel.Visible = False
      End Select

      Dim responseFromServer As String

      responseFromServer = RetrieveData(url)
      'Populate Edit Screen
      Using reader As XmlReader = XmlReader.Create(New StringReader(responseFromServer))


         Select Case Action(0)
            Case 999
               EditComunicationPanel.Visible = True

               PopulateCommDropdown()

               reader.ReadToFollowing("communication")
               reader.MoveToFirstAttribute()
               CommIDLabel.Text = reader.Value

               reader.ReadToFollowing("communicationType")
               reader.MoveToFirstAttribute()
               CommDropDownList.SelectedValue = reader.Value

               reader.ReadToFollowing("communicationGeneralType")
               reader.MoveToFirstAttribute()
               ID = reader.ReadElementContentAsString()

               reader.ReadToFollowing("communicationValue")
               reader.MoveToFirstAttribute()
               ValueTextBox.Text = reader.ReadElementContentAsString()

               reader.ReadToFollowing("listed")
               reader.MoveToFirstAttribute()
               Dim Listed = reader.ReadElementContentAsString()

               If Listed = True Then
                  ListRadioList.SelectedValue = 1
               Else
                  ListRadioList.SelectedValue = 0
               End If

               reader.ReadToFollowing("communicationComment")
               reader.MoveToFirstAttribute()
               EditCommentTextBox.Text = reader.ReadElementContentAsString()

               reader.Close()
            Case 997
               EDITAddressPanel.Visible = True

               PopulateAddDropdown()

               reader.ReadToFollowing("address")
               reader.MoveToFirstAttribute()
               AddressIDLabel.Text = reader.Value

               reader.ReadToFollowing("addressType")
               reader.MoveToFirstAttribute()
               UpdateDropdownList.SelectedValue = reader.Value

               reader.ReadToFollowing("address1")
               reader.MoveToFirstAttribute()
               AddAddressTextBox.Text = reader.ReadElementContentAsString()

               reader.ReadToFollowing("address2")
               reader.MoveToFirstAttribute()
               AddAddressTextBox2.Text = reader.ReadElementContentAsString()

               reader.ReadToFollowing("address3")
               reader.MoveToFirstAttribute()
               AddAddressTextBox3.Text = reader.ReadElementContentAsString()

               reader.ReadToFollowing("city")
               reader.MoveToFirstAttribute()
               AddCityTextBox.Text = reader.ReadElementContentAsString()

               reader.ReadToFollowing("postalCode")
               reader.MoveToFirstAttribute()
               AddPostalTextBox.Text = reader.ReadElementContentAsString()

               reader.ReadToFollowing("country")
               reader.MoveToFirstAttribute()
               CountryAddTextBox.Text = reader.ReadElementContentAsString()

               reader.ReadToFollowing("stProvince")
               reader.MoveToFirstAttribute()
               StADDTextBox.Text = reader.ReadElementContentAsString()

               reader.ReadToFollowing("addressComment")
               reader.MoveToFirstAttribute()
               AddCommentTextBox.Text = reader.ReadElementContentAsString()
               reader.Close()

         End Select
      End Using

   End Sub
   Protected Sub PopulateCommDropdown()
      Dim url As String = "https://demo.fellowshiponeapi.com/v1/Communications/CommunicationTypes?mode=demo"
      Dim responseFromServer As String = RetrieveData(url)

      Dim XMLDoc = New DataSet
      XMLDoc.ReadXml(New StringReader(responseFromServer))
      CommAddDropDownList.DataSource = XMLDoc
      CommAddDropDownList.DataValueField = "id"
      CommAddDropDownList.DataTextField = "name"
      CommAddDropDownList.DataBind()
      'Populate Address

      CommDropDownList.DataSource = XMLDoc
      CommDropDownList.DataValueField = "id"
      CommDropDownList.DataTextField = "name"
      CommDropDownList.DataBind()

   End Sub
   Protected Sub PopulateAddDropdown()
      Dim url As String = "https://demo.fellowshiponeapi.com/v1/Addresses/AddressTypes?mode=demo"
      Dim responseFromServer As String = RetrieveData(url)

      Dim XMLDoc = New DataSet
      XMLDoc.ReadXml(New StringReader(responseFromServer))
      AddAddressDropdown.DataSource = XMLDoc
      AddAddressDropdown.DataValueField = "id"
      AddAddressDropdown.DataTextField = "name"
      AddAddressDropdown.DataBind()

      UpdateDropdownList.DataSource = XMLDoc
      UpdateDropdownList.DataValueField = "id"
      UpdateDropdownList.DataTextField = "name"
      UpdateDropdownList.DataBind()

      'Populate Address
   End Sub
   Protected Sub Communication_Click(sender As Object, e As System.EventArgs) Handles UpdateButton.Click

      'Update Communications
      Dim xmlDoc As String = "<communication id='" & CommIDLabel.Text & "'>" & _
                                "<household id='" & Request.QueryString("HID") & "'/>" & _
                                "<person id='" & Request.QueryString("ID") & "'/>" & _
                                "<communicationType id='" & CommDropDownList.SelectedValue.ToString() & "'>" & _
                                    "<name>" & CommDropDownList.SelectedItem.ToString() & "</name>" & _
                                "</communicationType>" & _
                                "<communicationGeneralType></communicationGeneralType>" & _
                                "<communicationValue>" & ValueTextBox.Text & "</communicationValue>" & _
                                "<searchCommunicationValue>" & ValueAddCommTextBox.Text & "</searchCommunicationValue>" & _
                                "<listed>" & ListRadioList.SelectedValue & "</listed>" & _
                                "<communicationComment><![CDATA[" & EditCommentTextBox.Text & "]]></communicationComment>" & _
                                "<createdDate></createdDate>" & _
                                "<lastUpdatedDate></lastUpdatedDate>" & _
                            "</communication>"


      Dim URL = " https://demo.fellowshiponeapi.com/v1/People/" & Request.QueryString("ID") & "/Communications/" & CommIDLabel.Text & "?mode=demo"

      'Commit post here with 
      PostXMLData(URL, 2, xmlDoc)
      Redirect()
   End Sub

   Protected Sub Redirect()
      Response.Redirect("UserEdit.aspx?id=" & Request.QueryString("ID") & "&hid=" & Request.QueryString("HID"))

   End Sub

   Protected Sub CommFormat_Click(sender As Object, e As System.EventArgs) Handles Button1.Click

      Dim URL As String = "https://demo.fellowshiponeapi.com/v1/People/" & Request.QueryString("ID") & "/Communications?mode=demo"
      Dim xmlDoc As String = "<communication id=''>" & _
                                 "<household id=''/>" & _
                                 "<person id='" & Request.QueryString("ID") & "' />" & _
                                 "<communicationType id='" & CommAddDropDownList.SelectedValue & "'>" & _
                                     "<name></name>" & _
                                 "</communicationType>" & _
                                 "<communicationGeneralType></communicationGeneralType>" & _
                                 "<communicationValue>" & ValueAddCommTextBox.Text & "</communicationValue>" & _
                                 "<searchCommunicationValue>" & ValueAddCommTextBox.Text & "</searchCommunicationValue>" & _
                                 "<listed>" & RadioButtonList1.SelectedValue & "</listed>" & _
                                 "<communicationComment><![CDATA[" & CommADDCommentsTextBox.Text & "]]></communicationComment>" & _
                                 "<createdDate></createdDate>" & _
                                 "<lastUpdatedDate></lastUpdatedDate>" & _
                             "</communication>"


      'Commit post here with 
      PostXMLData(URL, 2, xmlDoc)
      Redirect()

   End Sub

   Protected Sub AddressAddLinkButton_Click(sender As Object, e As System.EventArgs) Handles AddressAddLinkButton.Click
      ADDAddressPanel.Visible = True
      CommListView.Visible = False
      EditComunicationPanel.Visible = False
      EDITAddressPanel.Visible = False
      AAListView1.Visible = False

      PopulateAddDropdown()

   End Sub

   Protected Sub CommAddLinkButton_Click(sender As Object, e As System.EventArgs) Handles CommAddLinkButton.Click
      CommListView.Visible = False
      EditComunicationPanel.Visible = False
      EDITAddressPanel.Visible = False
      AAListView1.Visible = False
      ADDAddressPanel.Visible = False
      ADDCommunicationsPanel.Visible = True
      PopulateCommDropdown()


   End Sub


   Protected Sub AddressUpdate_Click(sender As Object, e As System.EventArgs) Handles AddressUpdate.Click
      Dim xmlDoc As String = "<address id='" & AddressIDLabel.Text & "' >" & _
           "<household id='" & Request.QueryString("HID") & "' />" & _
           "<person id='" & Request.QueryString("ID") & "'  />" & _
           "<addressType id='" & UpdateDropdownList.SelectedValue & "' >" & _
           "<name></name>" & _
           "</addressType>" & _
           "<address1>" & AddAddressTextBox.Text & "</address1>" & _
           "<address2>" & AddAddressTextBox2.Text & "</address2>" & _
           "<address3>" & AddAddressTextBox3.Text & "</address3>" & _
           "<city>" & AddCityTextBox.Text & "</city>" & _
           "<postalCode>" & AddPostalTextBox.Text & "</postalCode>" & _
           "<county></county>" & _
           "<country>" & CountryAddTextBox.Text & "</country>" & _
           "<stProvince>" & StADDTextBox.Text & "</stProvince>" & _
           "<carrierRoute></carrierRoute>" & _
           "<deliveryPoint></deliveryPoint>" & _
           "<addressDate></addressDate>" & _
           "<addressComment><![CDATA[" & AddCommentTextBox.Text & "]]></addressComment>" & _
           "<uspsVerified>false</uspsVerified>" & _
           "<addressVerifiedDate></addressVerifiedDate>" & _
           "<lastVerificationAttemptDate></lastVerificationAttemptDate>" & _
           "<createdDate></createdDate>" & _
           "<lastUpdatedDate></lastUpdatedDate>" & _
           "</address>"
      Dim URL = "https://demo.fellowshiponeapi.com/v1/Addresses/" & AddressIDLabel.Text & "?mode=demo"

      'Commit post here with 
      PostXMLData(URL, 2, xmlDoc)

      'refresh page
      Redirect()
   End Sub

   Protected Sub ViewLinkButton_Click(sender As Object, e As System.EventArgs) Handles ViewLinkButton.Click
      CommListView.Visible = True
      EditComunicationPanel.Visible = False
      EDITAddressPanel.Visible = False
      AAListView1.Visible = True
      ADDAddressPanel.Visible = False
   End Sub

   Protected Sub Button_Click(sender As Object, e As System.EventArgs) Handles Button.Click
      'Add Address Information Here
      Dim URL As String = "https://demo.fellowshiponeapi.com/v1/People/" & Request.QueryString("ID") & "/Addresses?mode=demo"

      Dim xmlDoc As String = "<address id='" & CommIDLabel.Text & "' >" & _
           "<household id='" & Request.QueryString("HID") & "' />" & _
           "<person id='" & Request.QueryString("ID") & "'  />" & _
           "<addressType id='" & AddAddressDropdown.SelectedValue & "' >" & _
           "<name></name>" & _
           "</addressType>" & _
           "<address1>" & AddTextBox.Text & "</address1>" & _
           "<address2></address2>" & _
           "<address3></address3>" & _
           "<city>" & CityTextBox.Text & "</city>" & _
           "<postalCode>" & PostalCodeTextBox.Text & "</postalCode>" & _
           "<county></county>" & _
           "<country>" & CountryTextBox.Text & "</country>" & _
           "<stProvince>" & StateTextBox.Text & "</stProvince>" & _
           "<carrierRoute></carrierRoute>" & _
           "<deliveryPoint></deliveryPoint>" & _
           "<addressDate></addressDate>" & _
           "<addressComment><![CDATA[" & AddComment.Text & "]]></addressComment>" & _
           "<uspsVerified>false</uspsVerified>" & _
           "<addressVerifiedDate></addressVerifiedDate>" & _
           "<lastVerificationAttemptDate></lastVerificationAttemptDate>" & _
           "<createdDate></createdDate>" & _
           "<lastUpdatedDate></lastUpdatedDate>" & _
           "</address>"

      'Commit post here with 
      PostXMLData(URL, 2, xmlDoc)
      Redirect()


   End Sub
   Function DoSomething(ByRef value As String) As String
      Dim time As DateTime
      If value <> "" Then

         time = Convert.ToDateTime(value).ToString("d")
         Return time
      Else
         Return value
      End If

   End Function
   Function DoSomething2(ByRef value As String) As String
      Dim response As String = ""
      If value <> "" Then
         Return value
      End If
      Return response
   End Function

   
End Class