﻿Imports Microsoft.VisualBasic
Imports System.Net
Imports System.IO

Public Class SearchXML
   Public Class SearchXML
      Public Shared Function RetrieveData(ByVal URL As String) As String

         Dim request As WebRequest
         Dim response As HttpWebResponse
         Dim dataStream As Stream
         Dim reader As StreamReader
         Dim responseFromServer As String

            request = WebRequest.Create(URL)
            request.Timeout = 15 * 1000
            response = CType(request.GetResponse(), HttpWebResponse)

            Console.WriteLine(response.StatusDescription)

            dataStream = response.GetResponseStream
            ' Open the stream using a StreamReader for easy access.
            reader = New StreamReader(dataStream)

            ' Read the content.
            responseFromServer = reader.ReadToEnd()


            response.Close()

            Return responseFromServer

        End Function

        Public Shared Function PostXMLData(ByVal URL As String, POSTID As Integer, ByVal XMLDoc As String) As String
            '********************************************
            'POST DATA TO SERVER:
            Dim DemoResponse As String = ""
            Dim DemoHeaders As String = ""
            Dim myException As String = ""
            Dim Receive_Time As Integer = 15
            Dim Method As String = ""
            Dim Bytes As Byte()


            Select Case POSTID
                Case 1
                    Method = "GET"
                Case 2
                    Method = "POST"
                Case 3
                    Method = "DELETE"
            End Select

            Bytes = Encoding.UTF8.GetBytes(XMLDoc)
            Dim Request As HttpWebRequest
            Request = HttpWebRequest.Create(URL)
            Request.Timeout = Receive_Time * 1000 'in milliseconds
            Request.Method = Method
            Request.ContentLength = Len(XMLDoc)
            Request.ContentType = "application/xml"

            Dim myWriter As StreamWriter = New StreamWriter(Request.GetRequestStream())
            Try
                myWriter.Write(XMLDoc)
            Catch ex As Exception
                myException = "ERROR: " & ex.Message & " " & ex.StackTrace
            Finally
                myWriter.Close()
            End Try
            Dim myResponse As HttpWebResponse = CType(Request.GetResponse, HttpWebResponse)
            Dim ReceiveStream As Stream = myResponse.GetResponseStream

            myResponse.Close()

            Return myResponse.StatusCode
        End Function
   End Class
End Class
